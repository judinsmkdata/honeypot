import { formatDistanceToNow } from "date-fns";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  AlertTriangle,
  ShieldAlert,
  ShieldX,
  Shield,
  Activity,
} from "lucide-react";
import type { ThreatLog } from "@shared/schema";
import { cn } from "@/lib/utils";

interface ActivityFeedProps {
  logs: ThreatLog[];
  isLoading?: boolean;
  maxItems?: number;
}

const severityConfig = {
  low: {
    icon: Shield,
    className: "text-chart-5",
    bgClassName: "bg-chart-5/10",
  },
  medium: {
    icon: AlertTriangle,
    className: "text-chart-4",
    bgClassName: "bg-chart-4/10",
  },
  high: {
    icon: ShieldAlert,
    className: "text-chart-4",
    bgClassName: "bg-chart-4/10",
  },
  critical: {
    icon: ShieldX,
    className: "text-destructive",
    bgClassName: "bg-destructive/10",
  },
};

export function ActivityFeed({
  logs,
  isLoading,
  maxItems = 20,
}: ActivityFeedProps) {
  const recentLogs = logs.slice(0, maxItems);

  const formatThreatType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4" />
            Live Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-48">
            <div className="animate-pulse text-muted-foreground text-sm">
              Loading activity feed...
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <Activity className="h-4 w-4" />
            Live Activity
          </CardTitle>
          {recentLogs.length > 0 && (
            <Badge variant="outline" className="text-xs">
              {recentLogs.length} recent
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {recentLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-48 text-muted-foreground">
            <Shield className="h-8 w-8 mb-2 opacity-50" />
            <p className="text-sm">No recent activity</p>
            <p className="text-xs">Monitoring for threats...</p>
          </div>
        ) : (
          <ScrollArea className="h-[400px] pr-4">
            <div className="space-y-3">
              {recentLogs.map((log, index) => {
                const severity = severityConfig[log.severity];
                const SeverityIcon = severity.icon;
                return (
                  <div
                    key={log.id}
                    className={cn(
                      "flex items-start gap-3 p-3 rounded-md hover-elevate",
                      index === 0 && "animate-in fade-in-0 slide-in-from-top-2"
                    )}
                    data-testid={`activity-item-${log.id}`}
                  >
                    <div
                      className={cn(
                        "flex h-8 w-8 shrink-0 items-center justify-center rounded-md",
                        severity.bgClassName
                      )}
                    >
                      <SeverityIcon
                        className={cn("h-4 w-4", severity.className)}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium truncate">
                          {formatThreatType(log.threatType)}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <code className="text-xs font-mono text-muted-foreground">
                          {log.ipAddress}
                        </code>
                        <span className="text-xs text-muted-foreground">
                          {log.method}
                        </span>
                      </div>
                      <p className="text-xs text-muted-foreground truncate mt-1">
                        {log.path}
                      </p>
                    </div>
                    <span className="text-xs text-muted-foreground whitespace-nowrap">
                      {formatDistanceToNow(new Date(log.timestamp), {
                        addSuffix: true,
                      })}
                    </span>
                  </div>
                );
              })}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
}
