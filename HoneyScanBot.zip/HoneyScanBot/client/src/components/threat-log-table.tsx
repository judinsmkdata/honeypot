import { useState } from "react";
import { format } from "date-fns";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  ChevronLeft,
  ChevronRight,
  Search,
  AlertTriangle,
  ShieldAlert,
  ShieldX,
  Shield,
  Eye,
} from "lucide-react";
import type { ThreatLog } from "@shared/schema";
import { ThreatDetailDialog } from "./threat-detail-dialog";
import { cn } from "@/lib/utils";

interface ThreatLogTableProps {
  logs: ThreatLog[];
  isLoading?: boolean;
}

const severityConfig = {
  low: {
    label: "Low",
    icon: Shield,
    className: "bg-chart-5/10 text-chart-5 border-chart-5/20",
  },
  medium: {
    label: "Medium",
    icon: AlertTriangle,
    className: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  },
  high: {
    label: "High",
    icon: ShieldAlert,
    className: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  },
  critical: {
    label: "Critical",
    icon: ShieldX,
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
};

const methodColors: Record<string, string> = {
  GET: "bg-chart-2/10 text-chart-2 border-chart-2/20",
  POST: "bg-chart-1/10 text-chart-1 border-chart-1/20",
  PUT: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  DELETE: "bg-destructive/10 text-destructive border-destructive/20",
  PATCH: "bg-chart-3/10 text-chart-3 border-chart-3/20",
  OPTIONS: "bg-muted text-muted-foreground",
  HEAD: "bg-muted text-muted-foreground",
};

export function ThreatLogTable({ logs, isLoading }: ThreatLogTableProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedLog, setSelectedLog] = useState<ThreatLog | null>(null);
  const itemsPerPage = 15;

  const filteredLogs = logs.filter((log) => {
    const matchesSearch =
      log.ipAddress.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.path.toLowerCase().includes(searchQuery.toLowerCase()) ||
      log.threatType.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSeverity =
      severityFilter === "all" || log.severity === severityFilter;

    return matchesSearch && matchesSeverity;
  });

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage);
  const paginatedLogs = filteredLogs.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const formatThreatType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Threat Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-64">
            <div className="animate-pulse text-muted-foreground">
              Loading threat logs...
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="text-lg font-semibold">Threat Logs</CardTitle>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  placeholder="Search IP, path, type..."
                  value={searchQuery}
                  onChange={(e) => {
                    setSearchQuery(e.target.value);
                    setCurrentPage(1);
                  }}
                  className="pl-9 w-full sm:w-64"
                  data-testid="input-search-logs"
                />
              </div>
              <Select
                value={severityFilter}
                onValueChange={(value) => {
                  setSeverityFilter(value);
                  setCurrentPage(1);
                }}
              >
                <SelectTrigger
                  className="w-full sm:w-36"
                  data-testid="select-severity-filter"
                >
                  <SelectValue placeholder="Severity" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Severity</SelectItem>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="critical">Critical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {filteredLogs.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
              <Shield className="h-12 w-12 mb-4 opacity-50" />
              <p className="text-lg font-medium">No threats detected</p>
              <p className="text-sm">
                {logs.length === 0
                  ? "The honeypot is actively monitoring for suspicious activity"
                  : "No logs match your current filters"}
              </p>
            </div>
          ) : (
            <>
              <ScrollArea className="h-[500px]">
                <Table>
                  <TableHeader className="sticky top-0 bg-card z-10">
                    <TableRow>
                      <TableHead className="w-40">Timestamp</TableHead>
                      <TableHead className="w-32">IP Address</TableHead>
                      <TableHead className="w-20">Method</TableHead>
                      <TableHead>Path</TableHead>
                      <TableHead className="w-40">Threat Type</TableHead>
                      <TableHead className="w-24">Severity</TableHead>
                      <TableHead className="w-16">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedLogs.map((log) => {
                      const severity = severityConfig[log.severity];
                      const SeverityIcon = severity.icon;
                      return (
                        <TableRow
                          key={log.id}
                          className="hover-elevate cursor-pointer"
                          onClick={() => setSelectedLog(log)}
                          data-testid={`row-log-${log.id}`}
                        >
                          <TableCell className="font-mono text-xs text-muted-foreground">
                            {format(
                              new Date(log.timestamp),
                              "MMM dd, HH:mm:ss"
                            )}
                          </TableCell>
                          <TableCell className="font-mono text-sm">
                            {log.ipAddress}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={cn(
                                "text-xs font-mono",
                                methodColors[log.method] || "bg-muted"
                              )}
                            >
                              {log.method}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-mono text-sm max-w-[200px] truncate">
                            {log.path}
                          </TableCell>
                          <TableCell className="text-sm">
                            {formatThreatType(log.threatType)}
                          </TableCell>
                          <TableCell>
                            <Badge
                              variant="outline"
                              className={cn("gap-1", severity.className)}
                            >
                              <SeverityIcon className="h-3 w-3" />
                              {severity.label}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedLog(log);
                              }}
                              data-testid={`button-view-${log.id}`}
                            >
                              <Eye className="h-4 w-4" />
                            </Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>

              {/* Pagination */}
              <div className="flex items-center justify-between pt-4 border-t mt-4">
                <p className="text-sm text-muted-foreground">
                  Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                  {Math.min(currentPage * itemsPerPage, filteredLogs.length)} of{" "}
                  {filteredLogs.length} entries
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                    data-testid="button-prev-page"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm text-muted-foreground px-2">
                    Page {currentPage} of {totalPages || 1}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      setCurrentPage((p) => Math.min(totalPages, p + 1))
                    }
                    disabled={currentPage === totalPages || totalPages === 0}
                    data-testid="button-next-page"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <ThreatDetailDialog
        log={selectedLog}
        open={!!selectedLog}
        onOpenChange={(open) => !open && setSelectedLog(null)}
      />
    </>
  );
}
