import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Bell, BellOff, Settings, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

interface TelegramStatusProps {
  status: "connected" | "disconnected" | "error";
  lastNotificationTime?: string;
}

const statusConfig = {
  connected: {
    label: "Connected",
    icon: CheckCircle,
    color: "text-chart-5",
    bgColor: "bg-chart-5/10",
    dotColor: "bg-status-online",
  },
  disconnected: {
    label: "Disconnected",
    icon: XCircle,
    color: "text-muted-foreground",
    bgColor: "bg-muted",
    dotColor: "bg-status-offline",
  },
  error: {
    label: "Error",
    icon: AlertCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
    dotColor: "bg-status-busy",
  },
};

export function TelegramStatus({
  status,
  lastNotificationTime,
}: TelegramStatusProps) {
  const config = statusConfig[status];
  const StatusIcon = config.icon;

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="gap-2"
          data-testid="button-telegram-status"
        >
          <div className="relative">
            {status === "connected" ? (
              <Bell className="h-4 w-4" />
            ) : (
              <BellOff className="h-4 w-4 text-muted-foreground" />
            )}
            <div
              className={cn(
                "absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full",
                config.dotColor
              )}
            />
          </div>
          <span className="hidden sm:inline text-sm">Telegram</span>
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72">
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-md",
                config.bgColor
              )}
            >
              <StatusIcon className={cn("h-5 w-5", config.color)} />
            </div>
            <div>
              <p className="font-medium">Telegram Bot</p>
              <div className="flex items-center gap-1.5">
                <div
                  className={cn("h-2 w-2 rounded-full", config.dotColor)}
                />
                <span className={cn("text-sm", config.color)}>
                  {config.label}
                </span>
              </div>
            </div>
          </div>

          {status === "connected" && (
            <div className="text-sm text-muted-foreground">
              <p>Notifications are being sent to your Telegram chat.</p>
              {lastNotificationTime && (
                <p className="mt-1">
                  Last notification:{" "}
                  <span className="text-foreground">
                    {new Date(lastNotificationTime).toLocaleString()}
                  </span>
                </p>
              )}
            </div>
          )}

          {status === "disconnected" && (
            <div className="text-sm text-muted-foreground">
              <p>
                Telegram bot is not configured. Add your bot token and chat ID
                to receive notifications.
              </p>
            </div>
          )}

          {status === "error" && (
            <div className="text-sm text-destructive">
              <p>
                There was an error connecting to Telegram. Please check your
                configuration.
              </p>
            </div>
          )}

          <Link href="/settings">
            <Button variant="outline" size="sm" className="w-full gap-2">
              <Settings className="h-4 w-4" />
              Configure Telegram
            </Button>
          </Link>
        </div>
      </PopoverContent>
    </Popover>
  );
}
