import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import {
  AlertTriangle,
  ShieldAlert,
  ShieldX,
  Shield,
  Copy,
  ShieldBan,
  Bell,
  Check,
} from "lucide-react";
import type { ThreatLog } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";

interface ThreatDetailDialogProps {
  log: ThreatLog | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const severityConfig = {
  low: {
    label: "Low",
    icon: Shield,
    className: "bg-chart-5/10 text-chart-5 border-chart-5/20",
  },
  medium: {
    label: "Medium",
    icon: AlertTriangle,
    className: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  },
  high: {
    label: "High",
    icon: ShieldAlert,
    className: "bg-chart-4/10 text-chart-4 border-chart-4/20",
  },
  critical: {
    label: "Critical",
    icon: ShieldX,
    className: "bg-destructive/10 text-destructive border-destructive/20",
  },
};

export function ThreatDetailDialog({
  log,
  open,
  onOpenChange,
}: ThreatDetailDialogProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  const blockIpMutation = useMutation({
    mutationFn: async (ipAddress: string) => {
      return apiRequest("POST", "/api/blocked-ips", {
        ipAddress,
        reason: `Blocked from threat log: ${log?.threatType}`,
        permanent: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blocked-ips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "IP Blocked",
        description: `${log?.ipAddress} has been blocked successfully.`,
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to block IP address.",
        variant: "destructive",
      });
    },
  });

  const sendNotificationMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/telegram/send", { logId: log?.id });
    },
    onSuccess: () => {
      toast({
        title: "Notification Sent",
        description: "Alert has been sent to Telegram.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send Telegram notification.",
        variant: "destructive",
      });
    },
  });

  if (!log) return null;

  const severity = severityConfig[log.severity];
  const SeverityIcon = severity.icon;

  const formatThreatType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const copyToClipboard = async () => {
    const text = JSON.stringify(log, null, 2);
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast({
      title: "Copied",
      description: "Threat details copied to clipboard.",
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh]">
        <DialogHeader>
          <div className="flex items-center gap-3">
            <div
              className={cn(
                "flex h-10 w-10 items-center justify-center rounded-md",
                severity.className
              )}
            >
              <SeverityIcon className="h-5 w-5" />
            </div>
            <div>
              <DialogTitle className="text-lg">
                {formatThreatType(log.threatType)}
              </DialogTitle>
              <DialogDescription className="font-mono text-sm">
                {log.ipAddress} • {format(new Date(log.timestamp), "PPpp")}
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <ScrollArea className="max-h-[60vh]">
          <div className="space-y-6 pr-4">
            {/* Severity & Status */}
            <div className="flex flex-wrap gap-2">
              <Badge variant="outline" className={cn("gap-1", severity.className)}>
                <SeverityIcon className="h-3 w-3" />
                {severity.label} Severity
              </Badge>
              {log.blocked && (
                <Badge variant="outline" className="gap-1 bg-destructive/10 text-destructive">
                  <ShieldBan className="h-3 w-3" />
                  Blocked
                </Badge>
              )}
              {log.notificationSent && (
                <Badge variant="outline" className="gap-1 bg-chart-5/10 text-chart-5">
                  <Bell className="h-3 w-3" />
                  Notified
                </Badge>
              )}
            </div>

            <Separator />

            {/* Request Details */}
            <div className="space-y-4">
              <h4 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                Request Details
              </h4>
              <div className="grid gap-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Method</span>
                  <Badge variant="outline" className="font-mono">
                    {log.method}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Path</span>
                  <code className="font-mono text-xs bg-muted px-2 py-1 rounded max-w-[300px] truncate">
                    {log.path}
                  </code>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">IP Address</span>
                  <code className="font-mono">{log.ipAddress}</code>
                </div>
                {log.userAgent && (
                  <div className="flex flex-col gap-1">
                    <span className="text-muted-foreground">User Agent</span>
                    <code className="font-mono text-xs bg-muted px-2 py-1 rounded break-all">
                      {log.userAgent}
                    </code>
                  </div>
                )}
              </div>
            </div>

            <Separator />

            {/* Description */}
            <div className="space-y-2">
              <h4 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                Analysis
              </h4>
              <p className="text-sm">{log.description}</p>
            </div>

            {/* Headers */}
            {log.headers && Object.keys(log.headers).length > 0 && (
              <>
                <Separator />
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                    Request Headers
                  </h4>
                  <div className="bg-muted rounded-md p-3 font-mono text-xs space-y-1">
                    {Object.entries(log.headers).map(([key, value]) => (
                      <div key={key} className="break-all">
                        <span className="text-muted-foreground">{key}:</span>{" "}
                        {value}
                      </div>
                    ))}
                  </div>
                </div>
              </>
            )}

            {/* Body */}
            {log.body && (
              <>
                <Separator />
                <div className="space-y-2">
                  <h4 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
                    Request Body
                  </h4>
                  <pre className="bg-muted rounded-md p-3 font-mono text-xs overflow-x-auto">
                    {log.body}
                  </pre>
                </div>
              </>
            )}
          </div>
        </ScrollArea>

        {/* Actions */}
        <div className="flex flex-wrap gap-2 pt-4 border-t">
          <Button
            variant="outline"
            size="sm"
            onClick={copyToClipboard}
            className="gap-2"
            data-testid="button-copy-details"
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied" : "Copy Details"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => blockIpMutation.mutate(log.ipAddress)}
            disabled={log.blocked || blockIpMutation.isPending}
            className="gap-2"
            data-testid="button-block-ip"
          >
            <ShieldBan className="h-4 w-4" />
            {log.blocked ? "Already Blocked" : "Block IP"}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => sendNotificationMutation.mutate()}
            disabled={sendNotificationMutation.isPending}
            className="gap-2"
            data-testid="button-send-telegram"
          >
            <Bell className="h-4 w-4" />
            Send to Telegram
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
