import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import {
  ShieldBan,
  Trash2,
  Plus,
  Search,
  Clock,
  Ban,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import type { BlockedIp } from "@shared/schema";

const blockIpSchema = z.object({
  ipAddress: z.string().min(1, "IP address is required").regex(
    /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
    "Invalid IP address format"
  ),
  reason: z.string().min(1, "Reason is required"),
  permanent: z.boolean().default(false),
});

type BlockIpForm = z.infer<typeof blockIpSchema>;

export default function Blocked() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const form = useForm<BlockIpForm>({
    resolver: zodResolver(blockIpSchema),
    defaultValues: {
      ipAddress: "",
      reason: "",
      permanent: false,
    },
  });

  const { data: blockedIps = [], isLoading } = useQuery<BlockedIp[]>({
    queryKey: ["/api/blocked-ips"],
  });

  const blockMutation = useMutation({
    mutationFn: async (data: BlockIpForm) => {
      return apiRequest("POST", "/api/blocked-ips", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blocked-ips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "IP Blocked",
        description: "The IP address has been blocked successfully.",
      });
      setDialogOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to block IP address.",
        variant: "destructive",
      });
    },
  });

  const unblockMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/blocked-ips/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/blocked-ips"] });
      queryClient.invalidateQueries({ queryKey: ["/api/stats"] });
      toast({
        title: "IP Unblocked",
        description: "The IP address has been unblocked.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to unblock IP address.",
        variant: "destructive",
      });
    },
  });

  const filteredIps = blockedIps.filter(
    (ip) =>
      ip.ipAddress.includes(searchQuery) ||
      ip.reason.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const onSubmit = (data: BlockIpForm) => {
    blockMutation.mutate(data);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <ShieldBan className="h-6 w-6" />
            Blocked IPs
          </h1>
          <p className="text-sm text-muted-foreground">
            Manage blocked IP addresses
          </p>
        </div>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2" data-testid="button-add-blocked-ip">
              <Plus className="h-4 w-4" />
              Block IP
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Block IP Address</DialogTitle>
              <DialogDescription>
                Add an IP address to the blocklist to prevent future access.
              </DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="ipAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>IP Address</FormLabel>
                      <FormControl>
                        <Input
                          placeholder="192.168.1.1"
                          {...field}
                          data-testid="input-block-ip"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reason</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Reason for blocking..."
                          {...field}
                          data-testid="input-block-reason"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="permanent"
                  render={({ field }) => (
                    <FormItem className="flex items-center justify-between rounded-lg border p-3">
                      <div className="space-y-0.5">
                        <FormLabel>Permanent Block</FormLabel>
                        <p className="text-xs text-muted-foreground">
                          Block this IP permanently (no expiration)
                        </p>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                          data-testid="switch-permanent"
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button
                    type="submit"
                    disabled={blockMutation.isPending}
                    data-testid="button-confirm-block"
                  >
                    {blockMutation.isPending ? "Blocking..." : "Block IP"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-destructive/10">
                <Ban className="h-5 w-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold">{blockedIps.length}</p>
                <p className="text-xs text-muted-foreground">Total Blocked</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-chart-4/10">
                <Clock className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {blockedIps.filter((ip) => !ip.permanent).length}
                </p>
                <p className="text-xs text-muted-foreground">Temporary</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                <ShieldBan className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {blockedIps.filter((ip) => ip.permanent).length}
                </p>
                <p className="text-xs text-muted-foreground">Permanent</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Blocked IPs Table */}
      <Card>
        <CardHeader className="pb-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <CardTitle className="text-lg">Blocked IP Addresses</CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search IP or reason..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 w-full sm:w-64"
                data-testid="input-search-blocked"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-pulse text-muted-foreground">
                Loading blocked IPs...
              </div>
            </div>
          ) : filteredIps.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-muted-foreground">
              <ShieldBan className="h-12 w-12 mb-4 opacity-50" />
              <p className="text-lg font-medium">No blocked IPs</p>
              <p className="text-sm">
                {blockedIps.length === 0
                  ? "Add IP addresses to block suspicious sources"
                  : "No IPs match your search"}
              </p>
            </div>
          ) : (
            <ScrollArea className="h-[400px]">
              <Table>
                <TableHeader className="sticky top-0 bg-card z-10">
                  <TableRow>
                    <TableHead>IP Address</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Blocked At</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-16">Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredIps.map((ip) => (
                    <TableRow key={ip.id} data-testid={`row-blocked-${ip.id}`}>
                      <TableCell className="font-mono">{ip.ipAddress}</TableCell>
                      <TableCell className="max-w-[200px] truncate">
                        {ip.reason}
                      </TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {format(new Date(ip.blockedAt), "MMM dd, HH:mm")}
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            ip.permanent
                              ? "bg-destructive/10 text-destructive"
                              : "bg-chart-4/10 text-chart-4"
                          }
                        >
                          {ip.permanent ? "Permanent" : "Temporary"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => unblockMutation.mutate(ip.id)}
                          disabled={unblockMutation.isPending}
                          data-testid={`button-unblock-${ip.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
