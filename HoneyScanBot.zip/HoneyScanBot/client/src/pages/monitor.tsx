import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Button } from "@/components/ui/button";
import {
  Activity,
  Pause,
  Play,
  Shield,
  ShieldAlert,
  ShieldX,
  AlertTriangle,
  Wifi,
  WifiOff,
} from "lucide-react";
import { format } from "date-fns";
import type { ThreatLog } from "@shared/schema";
import { cn } from "@/lib/utils";

const severityConfig = {
  low: {
    icon: Shield,
    className: "text-chart-5",
    bgClassName: "bg-chart-5/10",
    borderClassName: "border-chart-5/30",
  },
  medium: {
    icon: AlertTriangle,
    className: "text-chart-4",
    bgClassName: "bg-chart-4/10",
    borderClassName: "border-chart-4/30",
  },
  high: {
    icon: ShieldAlert,
    className: "text-chart-4",
    bgClassName: "bg-chart-4/10",
    borderClassName: "border-chart-4/30",
  },
  critical: {
    icon: ShieldX,
    className: "text-destructive",
    bgClassName: "bg-destructive/10",
    borderClassName: "border-destructive/30",
  },
};

export default function Monitor() {
  const [isPaused, setIsPaused] = useState(false);
  const [displayedLogs, setDisplayedLogs] = useState<ThreatLog[]>([]);

  const { data: logs = [], isLoading } = useQuery<ThreatLog[]>({
    queryKey: ["/api/logs"],
    refetchInterval: isPaused ? false : 2000,
  });

  useEffect(() => {
    if (!isPaused && logs.length > 0) {
      setDisplayedLogs(logs);
    }
  }, [logs, isPaused]);

  const formatThreatType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const threatsByMinute = displayedLogs.reduce(
    (acc, log) => {
      const minute = format(new Date(log.timestamp), "HH:mm");
      acc[minute] = (acc[minute] || 0) + 1;
      return acc;
    },
    {} as Record<string, number>
  );

  const last10Minutes = Object.entries(threatsByMinute)
    .slice(-10)
    .map(([time, count]) => ({ time, count }));

  return (
    <div className="space-y-6 p-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Activity className="h-6 w-6" />
            Live Monitor
          </h1>
          <p className="text-sm text-muted-foreground">
            Real-time threat detection feed
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Badge
            variant="outline"
            className={cn(
              "gap-2",
              isPaused
                ? "bg-chart-4/10 text-chart-4"
                : "bg-chart-5/10 text-chart-5"
            )}
          >
            {isPaused ? (
              <>
                <WifiOff className="h-3 w-3" />
                Paused
              </>
            ) : (
              <>
                <Wifi className="h-3 w-3 animate-pulse" />
                Live
              </>
            )}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsPaused(!isPaused)}
            className="gap-2"
            data-testid="button-toggle-pause"
          >
            {isPaused ? (
              <>
                <Play className="h-4 w-4" />
                Resume
              </>
            ) : (
              <>
                <Pause className="h-4 w-4" />
                Pause
              </>
            )}
          </Button>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="grid gap-4 grid-cols-2 sm:grid-cols-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold">{displayedLogs.length}</div>
            <p className="text-xs text-muted-foreground">Total Events</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-chart-5">
              {displayedLogs.filter((l) => l.severity === "low").length}
            </div>
            <p className="text-xs text-muted-foreground">Low Severity</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-chart-4">
              {
                displayedLogs.filter(
                  (l) => l.severity === "medium" || l.severity === "high"
                ).length
              }
            </div>
            <p className="text-xs text-muted-foreground">Medium/High</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-destructive">
              {displayedLogs.filter((l) => l.severity === "critical").length}
            </div>
            <p className="text-xs text-muted-foreground">Critical</p>
          </CardContent>
        </Card>
      </div>

      {/* Activity Timeline */}
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Live Feed
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="flex items-center justify-center h-96">
                <div className="animate-pulse text-muted-foreground">
                  Loading live feed...
                </div>
              </div>
            ) : displayedLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-96 text-muted-foreground">
                <Shield className="h-12 w-12 mb-4 opacity-50" />
                <p className="text-lg font-medium">No threats detected</p>
                <p className="text-sm">Monitoring for suspicious activity...</p>
              </div>
            ) : (
              <ScrollArea className="h-[500px] pr-4">
                <div className="space-y-2">
                  {displayedLogs.slice(0, 50).map((log, index) => {
                    const severity = severityConfig[log.severity];
                    const SeverityIcon = severity.icon;
                    return (
                      <div
                        key={log.id}
                        className={cn(
                          "flex items-start gap-4 p-4 rounded-md border",
                          severity.borderClassName,
                          severity.bgClassName,
                          index === 0 &&
                            !isPaused &&
                            "animate-in fade-in-0 slide-in-from-top-2"
                        )}
                        data-testid={`monitor-event-${log.id}`}
                      >
                        <div
                          className={cn(
                            "flex h-10 w-10 shrink-0 items-center justify-center rounded-md",
                            severity.bgClassName
                          )}
                        >
                          <SeverityIcon
                            className={cn("h-5 w-5", severity.className)}
                          />
                        </div>
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium">
                              {formatThreatType(log.threatType)}
                            </span>
                            <Badge variant="outline" className="text-xs font-mono">
                              {log.method}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <code className="font-mono">{log.ipAddress}</code>
                            <span>•</span>
                            <span className="font-mono truncate max-w-[300px]">
                              {log.path}
                            </span>
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {log.description}
                          </p>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-xs font-mono text-muted-foreground">
                            {format(new Date(log.timestamp), "HH:mm:ss")}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {format(new Date(log.timestamp), "MMM dd")}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </ScrollArea>
            )}
          </CardContent>
        </Card>

        {/* Mini Timeline Chart */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Threats per Minute</CardTitle>
          </CardHeader>
          <CardContent>
            {last10Minutes.length === 0 ? (
              <div className="flex items-center justify-center h-64 text-muted-foreground">
                <p className="text-sm">No data yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {last10Minutes.map(({ time, count }) => (
                  <div key={time} className="flex items-center gap-3">
                    <span className="text-xs font-mono text-muted-foreground w-12">
                      {time}
                    </span>
                    <div className="flex-1 h-6 bg-muted rounded-md overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-md transition-all duration-300"
                        style={{
                          width: `${Math.min(100, (count / Math.max(...last10Minutes.map((m) => m.count))) * 100)}%`,
                        }}
                      />
                    </div>
                    <span className="text-sm font-medium w-8 text-right">
                      {count}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
