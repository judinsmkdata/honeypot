import { useQuery } from "@tanstack/react-query";
import {
  ShieldAlert,
  Activity,
  ShieldBan,
  AlertTriangle,
} from "lucide-react";
import { StatCard } from "@/components/stat-card";
import { ActivityFeed } from "@/components/activity-feed";
import { ThreatLogTable } from "@/components/threat-log-table";
import type { ThreatLog, DashboardStats } from "@shared/schema";

export default function Dashboard() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
    refetchInterval: 5000,
  });

  const { data: logs = [], isLoading: logsLoading } = useQuery<ThreatLog[]>({
    queryKey: ["/api/logs"],
    refetchInterval: 5000,
  });

  return (
    <div className="space-y-6 p-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">
          Real-time security monitoring for smkdata.sch.id
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Threats"
          value={statsLoading ? "..." : stats?.totalThreats ?? 0}
          description="All time detected threats"
          icon={ShieldAlert}
          variant="default"
        />
        <StatCard
          title="Today's Threats"
          value={statsLoading ? "..." : stats?.threatsToday ?? 0}
          description="Threats detected today"
          icon={Activity}
          trend={
            stats?.threatsToday
              ? { value: 12, isPositive: true }
              : undefined
          }
          variant="warning"
        />
        <StatCard
          title="Critical Threats"
          value={statsLoading ? "..." : stats?.criticalThreats ?? 0}
          description="Requires immediate attention"
          icon={AlertTriangle}
          variant="danger"
        />
        <StatCard
          title="Blocked IPs"
          value={statsLoading ? "..." : stats?.blockedIps ?? 0}
          description="Currently blocked addresses"
          icon={ShieldBan}
          variant="success"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Threat Log Table */}
        <div className="lg:col-span-2">
          <ThreatLogTable logs={logs} isLoading={logsLoading} />
        </div>

        {/* Activity Feed */}
        <div className="lg:col-span-1">
          <ActivityFeed logs={logs} isLoading={logsLoading} />
        </div>
      </div>
    </div>
  );
}
