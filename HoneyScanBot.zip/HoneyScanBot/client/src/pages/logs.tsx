import { useQuery } from "@tanstack/react-query";
import { FileWarning } from "lucide-react";
import { ThreatLogTable } from "@/components/threat-log-table";
import type { ThreatLog } from "@shared/schema";

export default function Logs() {
  const { data: logs = [], isLoading } = useQuery<ThreatLog[]>({
    queryKey: ["/api/logs"],
    refetchInterval: 10000,
  });

  return (
    <div className="space-y-6 p-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <FileWarning className="h-6 w-6" />
          Threat Logs
        </h1>
        <p className="text-sm text-muted-foreground">
          Complete history of all detected threats and scanning attempts
        </p>
      </div>

      {/* Logs Table */}
      <ThreatLogTable logs={logs} isLoading={isLoading} />
    </div>
  );
}
