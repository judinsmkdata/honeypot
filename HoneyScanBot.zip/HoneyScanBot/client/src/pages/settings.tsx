import { useQuery, useMutation } from "@tanstack/react-query";
import { Bell, Send, CheckCircle, XCircle, AlertCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { telegramSettingsSchema, type TelegramSettings, type DashboardStats } from "@shared/schema";
import { cn } from "@/lib/utils";

const statusConfig = {
  connected: {
    label: "Connected",
    icon: CheckCircle,
    color: "text-chart-5",
    bgColor: "bg-chart-5/10",
  },
  disconnected: {
    label: "Disconnected",
    icon: XCircle,
    color: "text-muted-foreground",
    bgColor: "bg-muted",
  },
  error: {
    label: "Error",
    icon: AlertCircle,
    color: "text-destructive",
    bgColor: "bg-destructive/10",
  },
};

export default function Settings() {
  const { toast } = useToast();

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/stats"],
  });

  const { data: settings, isLoading } = useQuery<TelegramSettings>({
    queryKey: ["/api/telegram/settings"],
  });

  const form = useForm<TelegramSettings>({
    resolver: zodResolver(telegramSettingsSchema),
    defaultValues: settings || {
      enabled: true,
      minSeverity: "medium",
      rateLimitPerMinute: 10,
      targetDomain: "smkdata.sch.id",
    },
    values: settings,
  });

  const updateMutation = useMutation({
    mutationFn: async (data: TelegramSettings) => {
      return apiRequest("PATCH", "/api/telegram/settings", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/telegram/settings"] });
      toast({
        title: "Settings Saved",
        description: "Telegram settings have been updated.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save settings.",
        variant: "destructive",
      });
    },
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/telegram/test", undefined);
    },
    onSuccess: () => {
      toast({
        title: "Test Sent",
        description: "A test notification has been sent to Telegram.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send test notification. Check your configuration.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: TelegramSettings) => {
    updateMutation.mutate(data);
  };

  const telegramStatus = stats?.telegramStatus || "disconnected";
  const status = statusConfig[telegramStatus];
  const StatusIcon = status.icon;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-pulse text-muted-foreground">
          Loading settings...
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Page Header */}
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Bell className="h-6 w-6" />
          Telegram Settings
        </h1>
        <p className="text-sm text-muted-foreground">
          Configure Telegram notifications for threat alerts
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Settings Form */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure when and how to receive Telegram notifications
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <FormField
                    control={form.control}
                    name="enabled"
                    render={({ field }) => (
                      <FormItem className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">
                            Enable Notifications
                          </FormLabel>
                          <FormDescription>
                            Receive real-time alerts when threats are detected
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                            data-testid="switch-notifications"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="targetDomain"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Target Domain</FormLabel>
                        <FormControl>
                          <Input
                            {...field}
                            placeholder="smkdata.sch.id"
                            data-testid="input-target-domain"
                          />
                        </FormControl>
                        <FormDescription>
                          The domain being monitored by the honeypot
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="minSeverity"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Minimum Severity</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          value={field.value}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-min-severity">
                              <SelectValue placeholder="Select minimum severity" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="low">Low - All threats</SelectItem>
                            <SelectItem value="medium">Medium - Medium and above</SelectItem>
                            <SelectItem value="high">High - High and critical only</SelectItem>
                            <SelectItem value="critical">Critical - Critical only</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormDescription>
                          Only send notifications for threats at or above this severity
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="rateLimitPerMinute"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Rate Limit (per minute)</FormLabel>
                        <FormControl>
                          <Input
                            type="number"
                            min={1}
                            max={60}
                            {...field}
                            onChange={(e) => field.onChange(parseInt(e.target.value) || 10)}
                            data-testid="input-rate-limit"
                          />
                        </FormControl>
                        <FormDescription>
                          Maximum number of notifications per minute (1-60)
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex gap-3">
                    <Button
                      type="submit"
                      disabled={updateMutation.isPending}
                      data-testid="button-save-settings"
                    >
                      {updateMutation.isPending ? "Saving..." : "Save Settings"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>

        {/* Status Card */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Bot Status</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-3">
                <div
                  className={cn(
                    "flex h-12 w-12 items-center justify-center rounded-md",
                    status.bgColor
                  )}
                >
                  <StatusIcon className={cn("h-6 w-6", status.color)} />
                </div>
                <div>
                  <p className="font-medium">Telegram Bot</p>
                  <Badge
                    variant="outline"
                    className={cn("gap-1", status.bgColor, status.color)}
                  >
                    {status.label}
                  </Badge>
                </div>
              </div>

              <Separator />

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Target Domain</span>
                  <code className="font-mono text-xs">
                    {settings?.targetDomain || "smkdata.sch.id"}
                  </code>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Min Severity</span>
                  <Badge variant="outline" className="text-xs capitalize">
                    {settings?.minSeverity || "medium"}
                  </Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Rate Limit</span>
                  <span>{settings?.rateLimitPerMinute || 10}/min</span>
                </div>
              </div>

              <Separator />

              <Button
                variant="outline"
                className="w-full gap-2"
                onClick={() => testMutation.mutate()}
                disabled={testMutation.isPending || telegramStatus === "disconnected"}
                data-testid="button-test-telegram"
              >
                <Send className="h-4 w-4" />
                {testMutation.isPending ? "Sending..." : "Send Test Message"}
              </Button>

              {telegramStatus === "disconnected" && (
                <p className="text-xs text-muted-foreground text-center">
                  Configure TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in Secrets to enable notifications
                </p>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Setup Guide</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>To set up Telegram notifications:</p>
              <ol className="list-decimal list-inside space-y-2">
                <li>Create a bot via @BotFather on Telegram</li>
                <li>Copy the bot token</li>
                <li>Add the bot to your group or chat directly</li>
                <li>Get your chat ID from the API</li>
                <li>Add both to Replit Secrets</li>
              </ol>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
