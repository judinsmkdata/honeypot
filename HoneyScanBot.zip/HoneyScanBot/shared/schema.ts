import { z } from "zod";

// Threat severity levels
export const ThreatSeverity = {
  LOW: "low",
  MEDIUM: "medium",
  HIGH: "high",
  CRITICAL: "critical",
} as const;

export type ThreatSeverityType = (typeof ThreatSeverity)[keyof typeof ThreatSeverity];

// Threat types detected by honeypot
export const ThreatType = {
  PATH_TRAVERSAL: "path_traversal",
  SQL_INJECTION: "sql_injection",
  XSS_ATTEMPT: "xss_attempt",
  COMMAND_INJECTION: "command_injection",
  PORT_SCAN: "port_scan",
  DIRECTORY_ENUMERATION: "directory_enumeration",
  SENSITIVE_FILE_ACCESS: "sensitive_file_access",
  BRUTE_FORCE: "brute_force",
  SCANNER_DETECTED: "scanner_detected",
  SUSPICIOUS_USER_AGENT: "suspicious_user_agent",
  UNKNOWN: "unknown",
} as const;

export type ThreatTypeValue = (typeof ThreatType)[keyof typeof ThreatType];

// Threat log entry schema
export const threatLogSchema = z.object({
  id: z.string(),
  timestamp: z.string(),
  ipAddress: z.string(),
  method: z.string(),
  path: z.string(),
  userAgent: z.string().optional(),
  headers: z.record(z.string()).optional(),
  body: z.string().optional(),
  threatType: z.enum([
    "path_traversal",
    "sql_injection",
    "xss_attempt",
    "command_injection",
    "port_scan",
    "directory_enumeration",
    "sensitive_file_access",
    "brute_force",
    "scanner_detected",
    "suspicious_user_agent",
    "unknown",
  ]),
  severity: z.enum(["low", "medium", "high", "critical"]),
  description: z.string(),
  blocked: z.boolean().default(false),
  notificationSent: z.boolean().default(false),
});

export type ThreatLog = z.infer<typeof threatLogSchema>;

export const insertThreatLogSchema = threatLogSchema.omit({ id: true });
export type InsertThreatLog = z.infer<typeof insertThreatLogSchema>;

// Blocked IP schema
export const blockedIpSchema = z.object({
  id: z.string(),
  ipAddress: z.string(),
  blockedAt: z.string(),
  reason: z.string(),
  expiresAt: z.string().optional(),
  permanent: z.boolean().default(false),
});

export type BlockedIp = z.infer<typeof blockedIpSchema>;

export const insertBlockedIpSchema = blockedIpSchema.omit({ id: true });
export type InsertBlockedIp = z.infer<typeof insertBlockedIpSchema>;

// Telegram settings schema
export const telegramSettingsSchema = z.object({
  enabled: z.boolean().default(true),
  minSeverity: z.enum(["low", "medium", "high", "critical"]).default("medium"),
  rateLimitPerMinute: z.number().min(1).max(60).default(10),
  targetDomain: z.string().default("smkdata.sch.id"),
});

export type TelegramSettings = z.infer<typeof telegramSettingsSchema>;

// Dashboard stats schema
export const dashboardStatsSchema = z.object({
  totalThreats: z.number(),
  threatsToday: z.number(),
  blockedIps: z.number(),
  criticalThreats: z.number(),
  lastThreatTime: z.string().optional(),
  telegramStatus: z.enum(["connected", "disconnected", "error"]),
  threatsByType: z.record(z.number()),
  threatsBySeverity: z.record(z.number()),
});

export type DashboardStats = z.infer<typeof dashboardStatsSchema>;

// Keep existing user schema for compatibility
export const users = {
  id: z.string(),
  username: z.string(),
  password: z.string(),
};

export const insertUserSchema = z.object({
  username: z.string(),
  password: z.string(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = { id: string; username: string; password: string };
