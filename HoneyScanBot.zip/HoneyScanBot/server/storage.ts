import type { 
  ThreatLog, 
  InsertThreatLog, 
  BlockedIp, 
  InsertBlockedIp,
  TelegramSettings,
  DashboardStats 
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Threat logs
  getAllLogs(): Promise<ThreatLog[]>;
  getLogById(id: string): Promise<ThreatLog | undefined>;
  createLog(log: InsertThreatLog): Promise<ThreatLog>;
  updateLog(id: string, updates: Partial<ThreatLog>): Promise<ThreatLog | undefined>;
  
  // Blocked IPs
  getAllBlockedIps(): Promise<BlockedIp[]>;
  getBlockedIp(ipAddress: string): Promise<BlockedIp | undefined>;
  createBlockedIp(blockedIp: InsertBlockedIp): Promise<BlockedIp>;
  deleteBlockedIp(id: string): Promise<boolean>;
  isIpBlocked(ipAddress: string): Promise<boolean>;
  
  // Telegram settings
  getTelegramSettings(): Promise<TelegramSettings>;
  updateTelegramSettings(settings: Partial<TelegramSettings>): Promise<TelegramSettings>;
  
  // Stats
  getStats(): Promise<DashboardStats>;
}

export class MemStorage implements IStorage {
  private logs: Map<string, ThreatLog>;
  private blockedIps: Map<string, BlockedIp>;
  private telegramSettings: TelegramSettings;
  private notificationsSent: number;

  constructor() {
    this.logs = new Map();
    this.blockedIps = new Map();
    this.notificationsSent = 0;
    this.telegramSettings = {
      enabled: true,
      minSeverity: "medium",
      rateLimitPerMinute: 10,
      targetDomain: "smkdata.sch.id",
    };
  }

  // Threat Logs
  async getAllLogs(): Promise<ThreatLog[]> {
    const logs = Array.from(this.logs.values());
    return logs.sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }

  async getLogById(id: string): Promise<ThreatLog | undefined> {
    return this.logs.get(id);
  }

  async createLog(insertLog: InsertThreatLog): Promise<ThreatLog> {
    const id = randomUUID();
    const log: ThreatLog = {
      ...insertLog,
      id,
      blocked: insertLog.blocked ?? false,
      notificationSent: insertLog.notificationSent ?? false,
    };
    this.logs.set(id, log);
    return log;
  }

  async updateLog(id: string, updates: Partial<ThreatLog>): Promise<ThreatLog | undefined> {
    const log = this.logs.get(id);
    if (!log) return undefined;
    
    const updatedLog = { ...log, ...updates };
    this.logs.set(id, updatedLog);
    return updatedLog;
  }

  // Blocked IPs
  async getAllBlockedIps(): Promise<BlockedIp[]> {
    return Array.from(this.blockedIps.values()).sort((a, b) =>
      new Date(b.blockedAt).getTime() - new Date(a.blockedAt).getTime()
    );
  }

  async getBlockedIp(ipAddress: string): Promise<BlockedIp | undefined> {
    return Array.from(this.blockedIps.values()).find(
      (ip) => ip.ipAddress === ipAddress
    );
  }

  async createBlockedIp(insertBlockedIp: InsertBlockedIp): Promise<BlockedIp> {
    const id = randomUUID();
    const blockedIp: BlockedIp = {
      ...insertBlockedIp,
      id,
      permanent: insertBlockedIp.permanent ?? false,
    };
    this.blockedIps.set(id, blockedIp);
    return blockedIp;
  }

  async deleteBlockedIp(id: string): Promise<boolean> {
    return this.blockedIps.delete(id);
  }

  async isIpBlocked(ipAddress: string): Promise<boolean> {
    const blockedIp = await this.getBlockedIp(ipAddress);
    if (!blockedIp) return false;
    
    // Check expiration for non-permanent blocks
    if (!blockedIp.permanent && blockedIp.expiresAt) {
      if (new Date(blockedIp.expiresAt) < new Date()) {
        await this.deleteBlockedIp(blockedIp.id);
        return false;
      }
    }
    return true;
  }

  // Telegram Settings
  async getTelegramSettings(): Promise<TelegramSettings> {
    return this.telegramSettings;
  }

  async updateTelegramSettings(settings: Partial<TelegramSettings>): Promise<TelegramSettings> {
    this.telegramSettings = { ...this.telegramSettings, ...settings };
    return this.telegramSettings;
  }

  incrementNotificationCount() {
    this.notificationsSent++;
  }

  // Stats
  async getStats(): Promise<DashboardStats> {
    const allLogs = await this.getAllLogs();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    const threatsToday = allLogs.filter(
      (log) => new Date(log.timestamp) >= today
    ).length;

    const criticalThreats = allLogs.filter(
      (log) => log.severity === "critical"
    ).length;

    const blockedIps = await this.getAllBlockedIps();

    const threatsByType = allLogs.reduce(
      (acc, log) => {
        acc[log.threatType] = (acc[log.threatType] || 0) + 1;
        return acc;
      },
      {} as Record<string, number>
    );

    const threatsBySeverity = allLogs.reduce(
      (acc, log) => {
        acc[log.severity] = (acc[log.severity] || 0) + 1;
        return acc;
      },
      {} as Record<string, number>
    );

    // Check telegram status
    const hasTelegramConfig = !!(
      process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID
    );

    return {
      totalThreats: allLogs.length,
      threatsToday,
      blockedIps: blockedIps.length,
      criticalThreats,
      lastThreatTime: allLogs[0]?.timestamp,
      telegramStatus: hasTelegramConfig ? "connected" : "disconnected",
      threatsByType,
      threatsBySeverity,
    };
  }
}

export const storage = new MemStorage();
