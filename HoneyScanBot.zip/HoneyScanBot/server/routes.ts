import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { detectThreat, createThreatLog, isSafePath, getClientIp } from "./honeypot";
import { sendTelegramNotification, sendTestNotification, isTelegramConfigured } from "./telegram";
import { insertBlockedIpSchema, telegramSettingsSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Honeypot middleware - must be before API routes
  app.use(async (req: Request, res: Response, next: NextFunction) => {
    // Skip safe paths (API, assets, etc)
    if (isSafePath(req.path)) {
      return next();
    }

    // Check if IP is blocked
    const clientIp = getClientIp(req);
    const isBlocked = await storage.isIpBlocked(clientIp);
    
    if (isBlocked) {
      console.log(`[Honeypot] Blocked request from ${clientIp} to ${req.path}`);
      return res.status(403).json({ error: "Access denied" });
    }

    // Detect threats
    const detection = detectThreat(req);
    
    if (detection) {
      const threatLog = createThreatLog(req, detection);
      const savedLog = await storage.createLog(threatLog);
      
      console.log(`[Honeypot] Threat detected: ${detection.threatType} from ${clientIp}`);
      
      // Send Telegram notification
      const settings = await storage.getTelegramSettings();
      if (isTelegramConfigured()) {
        const notificationSent = await sendTelegramNotification(savedLog, settings);
        if (notificationSent) {
          await storage.updateLog(savedLog.id, { notificationSent: true });
        }
      }
      
      // Return a honeypot response to confuse attackers
      return res.status(200).json({
        status: "ok",
        message: "Request processed",
      });
    }

    next();
  });

  // API Routes
  
  // Get all logs
  app.get("/api/logs", async (_req: Request, res: Response) => {
    try {
      const logs = await storage.getAllLogs();
      res.json(logs);
    } catch (error) {
      console.error("Error fetching logs:", error);
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  // Get single log
  app.get("/api/logs/:id", async (req: Request, res: Response) => {
    try {
      const log = await storage.getLogById(req.params.id);
      if (!log) {
        return res.status(404).json({ error: "Log not found" });
      }
      res.json(log);
    } catch (error) {
      console.error("Error fetching log:", error);
      res.status(500).json({ error: "Failed to fetch log" });
    }
  });

  // Get dashboard stats
  app.get("/api/stats", async (_req: Request, res: Response) => {
    try {
      const stats = await storage.getStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // Blocked IPs
  app.get("/api/blocked-ips", async (_req: Request, res: Response) => {
    try {
      const blockedIps = await storage.getAllBlockedIps();
      res.json(blockedIps);
    } catch (error) {
      console.error("Error fetching blocked IPs:", error);
      res.status(500).json({ error: "Failed to fetch blocked IPs" });
    }
  });

  app.post("/api/blocked-ips", async (req: Request, res: Response) => {
    try {
      const data = insertBlockedIpSchema.parse({
        ...req.body,
        blockedAt: new Date().toISOString(),
        expiresAt: req.body.permanent 
          ? undefined 
          : new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hours default
      });

      // Check if already blocked
      const existing = await storage.getBlockedIp(data.ipAddress);
      if (existing) {
        return res.status(409).json({ error: "IP already blocked" });
      }

      const blockedIp = await storage.createBlockedIp(data);
      res.status(201).json(blockedIp);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error blocking IP:", error);
      res.status(500).json({ error: "Failed to block IP" });
    }
  });

  app.delete("/api/blocked-ips/:id", async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteBlockedIp(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Blocked IP not found" });
      }
      res.status(204).send();
    } catch (error) {
      console.error("Error unblocking IP:", error);
      res.status(500).json({ error: "Failed to unblock IP" });
    }
  });

  // Telegram settings
  app.get("/api/telegram/settings", async (_req: Request, res: Response) => {
    try {
      const settings = await storage.getTelegramSettings();
      res.json(settings);
    } catch (error) {
      console.error("Error fetching Telegram settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  app.patch("/api/telegram/settings", async (req: Request, res: Response) => {
    try {
      const data = telegramSettingsSchema.partial().parse(req.body);
      const settings = await storage.updateTelegramSettings(data);
      res.json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      console.error("Error updating Telegram settings:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  app.post("/api/telegram/test", async (_req: Request, res: Response) => {
    try {
      await sendTestNotification();
      res.json({ success: true, message: "Test notification sent" });
    } catch (error) {
      console.error("Error sending test notification:", error);
      res.status(500).json({ 
        error: "Failed to send test notification",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.post("/api/telegram/send", async (req: Request, res: Response) => {
    try {
      const { logId } = req.body;
      if (!logId) {
        return res.status(400).json({ error: "Log ID required" });
      }

      const log = await storage.getLogById(logId);
      if (!log) {
        return res.status(404).json({ error: "Log not found" });
      }

      const settings = await storage.getTelegramSettings();
      const sent = await sendTelegramNotification(log, { ...settings, enabled: true });
      
      if (sent) {
        await storage.updateLog(logId, { notificationSent: true });
        res.json({ success: true });
      } else {
        res.status(500).json({ error: "Failed to send notification" });
      }
    } catch (error) {
      console.error("Error sending notification:", error);
      res.status(500).json({ error: "Failed to send notification" });
    }
  });

  return httpServer;
}
