import type { ThreatLog, TelegramSettings, ThreatSeverityType } from "@shared/schema";

const TELEGRAM_API_URL = "https://api.telegram.org/bot";

// Rate limiting
let lastNotificationTime = 0;
let notificationsThisMinute = 0;

const severityEmoji: Record<ThreatSeverityType, string> = {
  low: "INFO",
  medium: "WARNING",
  high: "ALERT",
  critical: "CRITICAL",
};

const severityOrder: Record<ThreatSeverityType, number> = {
  low: 0,
  medium: 1,
  high: 2,
  critical: 3,
};

export async function sendTelegramNotification(
  log: ThreatLog,
  settings: TelegramSettings
): Promise<boolean> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.log("[Telegram] Bot token or chat ID not configured");
    return false;
  }

  if (!settings.enabled) {
    console.log("[Telegram] Notifications disabled");
    return false;
  }

  // Check severity threshold
  if (severityOrder[log.severity] < severityOrder[settings.minSeverity]) {
    console.log(`[Telegram] Severity ${log.severity} below minimum ${settings.minSeverity}`);
    return false;
  }

  // Rate limiting
  const now = Date.now();
  const oneMinuteAgo = now - 60000;

  if (lastNotificationTime < oneMinuteAgo) {
    notificationsThisMinute = 0;
  }

  if (notificationsThisMinute >= settings.rateLimitPerMinute) {
    console.log("[Telegram] Rate limit exceeded");
    return false;
  }

  const formatThreatType = (type: string) => {
    return type
      .split("_")
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(" ");
  };

  const message = `
[${severityEmoji[log.severity]}] Honeypot Alert

Target: ${settings.targetDomain}
Threat: ${formatThreatType(log.threatType)}
Severity: ${log.severity.toUpperCase()}

IP Address: ${log.ipAddress}
Method: ${log.method}
Path: ${log.path}

${log.description}

Time: ${new Date(log.timestamp).toLocaleString()}
  `.trim();

  try {
    const response = await fetch(`${TELEGRAM_API_URL}${botToken}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
        disable_web_page_preview: true,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error("[Telegram] Failed to send notification:", error);
      return false;
    }

    lastNotificationTime = now;
    notificationsThisMinute++;
    
    console.log(`[Telegram] Notification sent for ${log.threatType} from ${log.ipAddress}`);
    return true;
  } catch (error) {
    console.error("[Telegram] Error sending notification:", error);
    return false;
  }
}

export async function sendTestNotification(): Promise<boolean> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    throw new Error("Telegram bot token or chat ID not configured");
  }

  const message = `
[TEST] Honeypot Monitor

This is a test notification from your Honeypot Monitor.

If you receive this message, your Telegram integration is working correctly!

Time: ${new Date().toLocaleString()}
  `.trim();

  try {
    const response = await fetch(`${TELEGRAM_API_URL}${botToken}/sendMessage`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        chat_id: chatId,
        text: message,
        parse_mode: "HTML",
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`Telegram API error: ${error}`);
    }

    return true;
  } catch (error) {
    console.error("[Telegram] Error sending test notification:", error);
    throw error;
  }
}

export function isTelegramConfigured(): boolean {
  return !!(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID);
}
