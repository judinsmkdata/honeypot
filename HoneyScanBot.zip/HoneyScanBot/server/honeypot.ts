import type { Request } from "express";
import type { InsertThreatLog, ThreatSeverityType, ThreatTypeValue } from "@shared/schema";
import { ThreatType, ThreatSeverity } from "@shared/schema";

// Suspicious paths that indicate scanning
const SUSPICIOUS_PATHS = [
  // Admin panels
  /\/admin/i,
  /\/wp-admin/i,
  /\/wp-login/i,
  /\/phpmyadmin/i,
  /\/cpanel/i,
  /\/administrator/i,
  /\/manager/i,
  /\/cms/i,
  
  // Config files
  /\.env/i,
  /\.git/i,
  /\.htaccess/i,
  /config\.(php|json|yml|yaml|xml|ini)/i,
  /web\.config/i,
  /\.DS_Store/i,
  
  // Backup files
  /\.(bak|backup|old|orig|save|swp|tmp)$/i,
  /backup/i,
  /dump/i,
  
  // Shell/backdoors
  /shell/i,
  /c99/i,
  /r57/i,
  /wso/i,
  /b374k/i,
  /alfa/i,
  
  // Common exploits
  /xmlrpc\.php/i,
  /wp-includes/i,
  /eval-stdin/i,
  /vendor/i,
  /debug/i,
];

// Path traversal patterns
const PATH_TRAVERSAL_PATTERNS = [
  /\.\.\//,
  /\.\.%2f/i,
  /\.\.%5c/i,
  /%2e%2e/i,
  /\.\.\\/,
  /etc\/passwd/i,
  /etc\/shadow/i,
  /windows\/system32/i,
  /boot\.ini/i,
];

// SQL Injection patterns
const SQL_INJECTION_PATTERNS = [
  /(\%27)|(\')|(\-\-)|(\%23)|(#)/i,
  /(\s|%20)*(union|select|insert|update|delete|drop|truncate|alter|exec|execute)(\s|%20)+/i,
  /1(\s|%20)*=(\s|%20)*1/i,
  /or(\s|%20)+1(\s|%20)*=(\s|%20)*1/i,
  /\'(\s|%20)*or(\s|%20)+/i,
  /benchmark\s*\(/i,
  /sleep\s*\(/i,
  /waitfor\s+delay/i,
];

// XSS patterns
const XSS_PATTERNS = [
  /<script/i,
  /javascript:/i,
  /on\w+\s*=/i,
  /expression\s*\(/i,
  /vbscript:/i,
  /<iframe/i,
  /<object/i,
  /<embed/i,
  /document\.cookie/i,
  /document\.write/i,
];

// Command injection patterns
const COMMAND_INJECTION_PATTERNS = [
  /;\s*(ls|cat|wget|curl|nc|bash|sh|python|perl|php|ruby)/i,
  /\|\s*(ls|cat|wget|curl|nc|bash|sh)/i,
  /`[^`]+`/,
  /\$\([^)]+\)/,
  /&&\s*(ls|cat|wget|curl|nc)/i,
];

// Suspicious user agents (scanners, bots)
const SUSPICIOUS_USER_AGENTS = [
  /nikto/i,
  /nmap/i,
  /masscan/i,
  /nuclei/i,
  /sqlmap/i,
  /wpscan/i,
  /dirbuster/i,
  /gobuster/i,
  /burpsuite/i,
  /zap/i,
  /acunetix/i,
  /nessus/i,
  /openvas/i,
  /arachni/i,
  /w3af/i,
  /vega/i,
  /scrapy/i,
  /python-requests/i,
  /curl\//i,
  /wget/i,
  /libwww-perl/i,
];

// Sensitive file extensions
const SENSITIVE_EXTENSIONS = [
  /\.(sql|db|sqlite|mdb)$/i,
  /\.(conf|cfg|config)$/i,
  /\.(log|logs)$/i,
  /\.(key|pem|crt|cer|p12|pfx)$/i,
  /\.(zip|tar|gz|rar|7z)$/i,
];

export interface ThreatDetection {
  detected: boolean;
  threatType: ThreatTypeValue;
  severity: ThreatSeverityType;
  description: string;
}

export function detectThreat(req: Request): ThreatDetection | null {
  const path = req.path || req.url || "";
  const query = req.query ? JSON.stringify(req.query) : "";
  const body = req.body ? JSON.stringify(req.body) : "";
  const userAgent = req.headers["user-agent"] || "";
  const fullUrl = path + "?" + query;
  const combinedInput = fullUrl + body;

  // Check for path traversal
  for (const pattern of PATH_TRAVERSAL_PATTERNS) {
    if (pattern.test(combinedInput)) {
      return {
        detected: true,
        threatType: ThreatType.PATH_TRAVERSAL,
        severity: ThreatSeverity.HIGH,
        description: `Path traversal attempt detected: ${pattern.toString().slice(1, -1)} pattern found in request`,
      };
    }
  }

  // Check for SQL injection
  for (const pattern of SQL_INJECTION_PATTERNS) {
    if (pattern.test(combinedInput)) {
      return {
        detected: true,
        threatType: ThreatType.SQL_INJECTION,
        severity: ThreatSeverity.CRITICAL,
        description: `SQL injection attempt detected in ${body ? "request body" : "URL parameters"}`,
      };
    }
  }

  // Check for XSS
  for (const pattern of XSS_PATTERNS) {
    if (pattern.test(combinedInput)) {
      return {
        detected: true,
        threatType: ThreatType.XSS_ATTEMPT,
        severity: ThreatSeverity.HIGH,
        description: `Cross-site scripting (XSS) attempt detected: potential script injection`,
      };
    }
  }

  // Check for command injection
  for (const pattern of COMMAND_INJECTION_PATTERNS) {
    if (pattern.test(combinedInput)) {
      return {
        detected: true,
        threatType: ThreatType.COMMAND_INJECTION,
        severity: ThreatSeverity.CRITICAL,
        description: `Command injection attempt detected: shell command patterns found`,
      };
    }
  }

  // Check for suspicious user agent
  for (const pattern of SUSPICIOUS_USER_AGENTS) {
    if (pattern.test(userAgent)) {
      return {
        detected: true,
        threatType: ThreatType.SCANNER_DETECTED,
        severity: ThreatSeverity.MEDIUM,
        description: `Security scanner detected: ${userAgent.substring(0, 50)}`,
      };
    }
  }

  // Check for sensitive file access
  for (const pattern of SENSITIVE_EXTENSIONS) {
    if (pattern.test(path)) {
      return {
        detected: true,
        threatType: ThreatType.SENSITIVE_FILE_ACCESS,
        severity: ThreatSeverity.HIGH,
        description: `Attempt to access sensitive file type: ${path}`,
      };
    }
  }

  // Check for suspicious paths (directory enumeration)
  for (const pattern of SUSPICIOUS_PATHS) {
    if (pattern.test(path)) {
      return {
        detected: true,
        threatType: ThreatType.DIRECTORY_ENUMERATION,
        severity: ThreatSeverity.MEDIUM,
        description: `Suspicious path access attempt: ${path}`,
      };
    }
  }

  // No threat detected
  return null;
}

export function createThreatLog(
  req: Request,
  detection: ThreatDetection
): InsertThreatLog {
  const ipAddress = getClientIp(req);
  
  // Sanitize headers - remove sensitive info
  const safeHeaders: Record<string, string> = {};
  const headersToInclude = [
    "user-agent",
    "accept",
    "accept-language",
    "accept-encoding",
    "referer",
    "origin",
    "content-type",
    "x-forwarded-for",
    "x-real-ip",
  ];
  
  for (const header of headersToInclude) {
    if (req.headers[header]) {
      const value = req.headers[header];
      safeHeaders[header] = Array.isArray(value) ? value.join(", ") : String(value);
    }
  }

  return {
    timestamp: new Date().toISOString(),
    ipAddress,
    method: req.method,
    path: req.path || req.url || "/",
    userAgent: req.headers["user-agent"],
    headers: safeHeaders,
    body: req.body ? JSON.stringify(req.body).substring(0, 1000) : undefined,
    threatType: detection.threatType,
    severity: detection.severity,
    description: detection.description,
    blocked: false,
    notificationSent: false,
  };
}

export function getClientIp(req: Request): string {
  const xForwardedFor = req.headers["x-forwarded-for"];
  if (xForwardedFor) {
    const ips = Array.isArray(xForwardedFor) 
      ? xForwardedFor[0] 
      : xForwardedFor.split(",")[0];
    return ips.trim();
  }
  
  const xRealIp = req.headers["x-real-ip"];
  if (xRealIp) {
    return Array.isArray(xRealIp) ? xRealIp[0] : xRealIp;
  }
  
  return req.ip || req.socket.remoteAddress || "unknown";
}

// Safe paths that should not be flagged (dashboard and legitimate assets)
const SAFE_PATHS = [
  // Root and app routes
  /^\/$/,
  /^\/monitor$/,
  /^\/logs$/,
  /^\/blocked$/,
  /^\/settings$/,
  /^\/index\.html$/,
  
  // API routes
  /^\/api\//,
  
  // Static assets and dev server
  /^\/assets\//,
  /^\/@/,
  /^\/src\//,
  /^\/node_modules\//,
  /^\/favicon/,
  /^\/public\//,
  
  // File extensions for assets
  /\.(js|mjs|jsx|ts|tsx|css|scss|less|png|jpg|jpeg|gif|svg|ico|woff|woff2|ttf|eot|map|json|html)$/i,
  
  // Vite HMR
  /^\/__vite/,
  /^\/vite/,
  /^\/@vite/,
  /^\/@react-refresh/,
  /^\/@id\//,
];

export function isSafePath(path: string): boolean {
  // Also ignore any path that's likely a frontend route (no file extension, no suspicious patterns)
  const isFrontendRoute = !path.includes('.') && 
    !path.includes('..') && 
    !path.includes('%') &&
    path.split('/').length <= 3;
  
  return SAFE_PATHS.some(pattern => pattern.test(path)) || 
    (isFrontendRoute && !SUSPICIOUS_PATHS.some(p => p.test(path)));
}
